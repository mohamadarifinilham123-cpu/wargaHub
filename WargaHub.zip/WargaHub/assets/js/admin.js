/* ADMIN WH — simulasi sisi browser (tugas kuliah). Data disimpan di localStorage. */
(function () {
  'use strict';

  var KEY_AUTH = 'wh_admin_auth';
  var KEY_REPORTS = 'wh_admin_reports';
  var KEY_RESIDENTS = 'wh_admin_residents';
  var DEMO_USER = 'admin', DEMO_PASS = 'admin123';

  var $ = function (id) { return document.getElementById(id); };

  /* ---------- storage ---------- */
  function load(key, seed) {
    try {
      var raw = localStorage.getItem(key);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    save(key, seed);
    return seed;
  }
  function save(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function fmtDate(s) {
    if (!s) return '-';
    var p = s.split('-');
    var bln = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return p.length === 3 ? parseInt(p[2], 10) + ' ' + bln[parseInt(p[1], 10) - 1] + ' ' + p[0] : s;
  }

  /* ---------- seed data (fiktif) ---------- */
  var seedReports = [
    { id: uid(), nama: 'Siti Aminah', kategori: 'Pengurusan KTP', isi: 'Sudah tiga kali ke kantor kecamatan tetapi perekaman KTP-el selalu ditunda karena alat rusak.', status: 'Baru', tanggal: '2026-11-15', catatan: '' },
    { id: uid(), nama: 'Budi Santoso', kategori: 'Kartu Keluarga', isi: 'Ingin menambahkan anak ke Kartu Keluarga tetapi tidak tahu dokumen apa saja yang perlu dibawa.', status: 'Diproses', tanggal: '2026-11-12', catatan: 'Sudah dihubungi, diminta membawa akta kelahiran asli.' },
    { id: uid(), nama: 'Dewi Lestari', kategori: 'Akta kelahiran', isi: 'Nama anak pada akta kelahiran salah satu huruf. Mohon informasi cara perbaikan.', status: 'Selesai', tanggal: '2026-11-03', catatan: 'Sudah diarahkan ke Disdukcapil, perbaikan selesai.' },
    { id: uid(), nama: 'Agus Prasetyo', kategori: 'Surat domisili', isi: 'Butuh surat domisili untuk melamar kerja tetapi petugas desa belum ada di tempat.', status: 'Baru', tanggal: '2026-11-16', catatan: '' }
  ];
  var seedResidents = [
    { id: uid(), nama: 'Siti Aminah', jk: 'P', lahir: '1990-04-12', nik: '3374010404900001', alamat: 'Dusun Krajan RT 01/RW 02', ktp: 'Belum punya', kk: 'Sudah punya', akta: 'Sudah punya' },
    { id: uid(), nama: 'Budi Santoso', jk: 'L', lahir: '1985-09-30', nik: '3374013009850002', alamat: 'Dusun Krajan RT 03/RW 02', ktp: 'Sudah punya', kk: 'Dalam proses', akta: 'Sudah punya' },
    { id: uid(), nama: 'Dewi Lestari', jk: 'P', lahir: '1995-01-22', nik: '3374016201950003', alamat: 'Dusun Sumber RT 02/RW 01', ktp: 'Sudah punya', kk: 'Sudah punya', akta: 'Dalam proses' },
    { id: uid(), nama: 'Agus Prasetyo', jk: 'L', lahir: '2001-07-08', nik: '3374010807010004', alamat: 'Dusun Sumber RT 04/RW 01', ktp: 'Dalam proses', kk: 'Sudah punya', akta: 'Belum punya' },
    { id: uid(), nama: 'Rina Wulandari', jk: 'P', lahir: '1978-11-05', nik: '3374014511780005', alamat: 'Dusun Kidul RT 01/RW 03', ktp: 'Sudah punya', kk: 'Sudah punya', akta: 'Sudah punya' }
  ];

  var reports = [];
  var residents = [];

  /* ---------- helpers DOM ---------- */
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function badge(text, cls) { return el('span', 'badge ' + cls, text); }
  function statusBadge(s) {
    return badge(s, s === 'Selesai' ? 'b-ok' : s === 'Diproses' ? 'b-warn' : 'b-info');
  }
  function docBadge(s) {
    return badge(s, s === 'Sudah punya' ? 'b-ok' : s === 'Dalam proses' ? 'b-warn' : 'b-bad');
  }
  function maskNik(n) { return n.length === 16 ? n.slice(0, 6) + '••••••' + n.slice(-4) : n; }
  function actionBtn(label, cls, handler) {
    var b = el('button', 'link-btn ' + (cls || ''), label);
    b.type = 'button';
    b.addEventListener('click', handler);
    return b;
  }
  function statTile(label, value, sub) {
    var d = el('div', 'stat');
    d.appendChild(el('span', null, label));
    d.appendChild(el('b', null, String(value)));
    if (sub) d.appendChild(el('small', null, sub));
    return d;
  }
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2400);
  }

  /* ---------- LOGIN ---------- */
  function isAuthed() { try { return sessionStorage.getItem(KEY_AUTH) === '1'; } catch (e) { return false; } }
  function showApp() {
    $('loginScreen').hidden = true;
    $('app').hidden = false;
    reports = load(KEY_REPORTS, seedReports);
    residents = load(KEY_RESIDENTS, seedResidents);
    renderReports();
    renderResidents();
    goPage(location.hash === '#warga' ? 'warga' : 'laporan');
  }
  function showLogin() {
    $('app').hidden = true;
    $('loginScreen').hidden = false;
  }

  $('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var u = $('loginUser').value.trim(), p = $('loginPass').value;
    if (u === DEMO_USER && p === DEMO_PASS) {
      try { sessionStorage.setItem(KEY_AUTH, '1'); } catch (er) {}
      $('loginError').textContent = '';
      $('loginForm').reset();
      showApp();
    } else {
      $('loginError').textContent = 'Username atau kata sandi salah.';
      $('loginPass').value = '';
      $('loginPass').focus();
    }
  });
  $('passToggle').addEventListener('click', function () {
    var inp = $('loginPass'), show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    this.textContent = show ? 'Sembunyi' : 'Lihat';
    this.setAttribute('aria-label', show ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
  });
  $('logoutBtn').addEventListener('click', function () {
    try { sessionStorage.removeItem(KEY_AUTH); } catch (e) {}
    showLogin();
  });

  /* ---------- NAVIGASI ---------- */
  var titles = {
    laporan: { eyebrow: 'LAPORAN', title: 'Laporan Masyarakat' },
    warga: { eyebrow: 'DATA WARGA', title: 'Data Warga' }
  };
  function goPage(name) {
    ['laporan', 'warga'].forEach(function (p) { $('page-' + p).hidden = p !== name; });
    document.querySelectorAll('.side-link').forEach(function (b) {
      b.classList.toggle('active', b.dataset.page === name);
    });
    $('pageEyebrow').textContent = titles[name].eyebrow;
    $('pageTitle').textContent = titles[name].title;
    closeSidebar();
    window.scrollTo(0, 0);
  }
  document.querySelectorAll('.side-link').forEach(function (b) {
    b.addEventListener('click', function () { goPage(b.dataset.page); });
  });
  function closeSidebar() {
    $('sidebar').classList.remove('open');
    $('menuToggle').setAttribute('aria-expanded', 'false');
  }
  $('menuToggle').addEventListener('click', function () {
    var open = $('sidebar').classList.toggle('open');
    this.setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSidebar(); });

  /* ---------- DIALOG umum ---------- */
  document.querySelectorAll('dialog [data-close]').forEach(function (b) {
    b.addEventListener('click', function () { b.closest('dialog').close(); });
  });
  document.querySelectorAll('dialog').forEach(function (d) {
    d.addEventListener('click', function (e) { if (e.target === d) d.close(); });
  });

  /* =========================================================
     PAGE 1: LAPORAN
     ========================================================= */
  function renderReports() {
    var q = $('reportSearch').value.trim().toLowerCase();
    var st = $('reportStatusFilter').value;
    var kt = $('reportKategoriFilter').value;

    var baru = reports.filter(function (r) { return r.status === 'Baru'; }).length;
    var proses = reports.filter(function (r) { return r.status === 'Diproses'; }).length;
    var selesai = reports.filter(function (r) { return r.status === 'Selesai'; }).length;

    var stats = $('reportStats');
    stats.textContent = '';
    stats.appendChild(statTile('Total laporan', reports.length, 'Semua laporan masuk'));
    stats.appendChild(statTile('Baru', baru, 'Perlu ditinjau'));
    stats.appendChild(statTile('Diproses', proses, 'Sedang ditindaklanjuti'));
    stats.appendChild(statTile('Selesai', selesai, 'Sudah tertangani'));

    var badgeEl = $('badgeBaru');
    badgeEl.textContent = baru;
    badgeEl.dataset.zero = String(baru === 0);

    var list = reports.filter(function (r) {
      if (st && r.status !== st) return false;
      if (kt && r.kategori !== kt) return false;
      if (q && (r.nama + ' ' + r.isi).toLowerCase().indexOf(q) === -1) return false;
      return true;
    }).sort(function (a, b) { return a.tanggal < b.tanggal ? 1 : -1; });

    var body = $('reportBody');
    body.textContent = '';
    list.forEach(function (r) {
      var tr = el('tr');
      tr.appendChild(el('td', null, fmtDate(r.tanggal)));
      var tdN = el('td'); tdN.appendChild(el('span', 'name', r.nama)); tr.appendChild(tdN);
      tr.appendChild(el('td', null, r.kategori));
      var tdS = el('td', 'summary'); tdS.appendChild(el('span', null, r.isi)); tr.appendChild(tdS);
      var tdSt = el('td'); tdSt.appendChild(statusBadge(r.status)); tr.appendChild(tdSt);
      var tdA = el('td', 'actions');
      tdA.appendChild(actionBtn('Detail', '', function () { openReport(r.id); }));
      tdA.appendChild(actionBtn('Hapus', 'del', function () { deleteReport(r.id); }));
      tr.appendChild(tdA);
      body.appendChild(tr);
    });
    $('reportEmpty').hidden = list.length > 0;
  }

  ['reportSearch', 'reportStatusFilter', 'reportKategoriFilter'].forEach(function (id) {
    $(id).addEventListener('input', renderReports);
    $(id).addEventListener('change', renderReports);
  });

  function openReport(id) {
    var r = id ? reports.filter(function (x) { return x.id === id; })[0] : null;
    $('reportDialogEyebrow').textContent = r ? 'DETAIL LAPORAN' : 'LAPORAN BARU';
    $('reportDialogTitle').textContent = r ? 'Laporan dari ' + r.nama : 'Tambah laporan';
    $('reportId').value = r ? r.id : '';
    $('reportName').value = r ? r.nama : '';
    $('reportKategori').value = r ? r.kategori : 'Pengurusan KTP';
    $('reportDesc').value = r ? r.isi : '';
    $('reportStatus').value = r ? r.status : 'Baru';
    $('reportDate').value = r ? r.tanggal : today();
    $('reportNote').value = r ? (r.catatan || '') : '';
    $('reportDeleteBtn').hidden = !r;
    $('reportDialog').showModal();
  }
  $('addReportBtn').addEventListener('click', function () { openReport(null); });

  $('reportForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var id = $('reportId').value;
    var data = {
      nama: $('reportName').value.trim(),
      kategori: $('reportKategori').value,
      isi: $('reportDesc').value.trim(),
      status: $('reportStatus').value,
      tanggal: $('reportDate').value,
      catatan: $('reportNote').value.trim()
    };
    if (!data.nama || !data.isi) return;
    if (id) {
      reports = reports.map(function (r) { return r.id === id ? Object.assign({}, r, data) : r; });
      toast('Laporan diperbarui');
    } else {
      data.id = uid();
      reports.push(data);
      toast('Laporan ditambahkan');
    }
    save(KEY_REPORTS, reports);
    $('reportDialog').close();
    renderReports();
  });

  function deleteReport(id) {
    var r = reports.filter(function (x) { return x.id === id; })[0];
    if (!r || !confirm('Hapus laporan dari ' + r.nama + '?')) return;
    reports = reports.filter(function (x) { return x.id !== id; });
    save(KEY_REPORTS, reports);
    renderReports();
    toast('Laporan dihapus');
  }
  $('reportDeleteBtn').addEventListener('click', function () {
    var id = $('reportId').value;
    if (!id) return;
    $('reportDialog').close();
    deleteReport(id);
  });

  /* =========================================================
     PAGE 2: DATA WARGA
     ========================================================= */
  function renderResidents() {
    var q = $('residentSearch').value.trim().toLowerCase();
    var jk = $('residentJkFilter').value;
    var doc = $('residentDocFilter').value;
    var full = $('showNik').checked;

    var total = residents.length;
    var lengkap = residents.filter(function (r) {
      return r.ktp === 'Sudah punya' && r.kk === 'Sudah punya' && r.akta === 'Sudah punya';
    }).length;
    var kurangKtp = residents.filter(function (r) { return r.ktp !== 'Sudah punya'; }).length;
    var kurangAkta = residents.filter(function (r) { return r.akta !== 'Sudah punya'; }).length;

    var stats = $('residentStats');
    stats.textContent = '';
    stats.appendChild(statTile('Total warga', total, 'Terdata di sistem'));
    stats.appendChild(statTile('Dokumen lengkap', lengkap, 'KTP, KK, dan akta'));
    stats.appendChild(statTile('KTP belum lengkap', kurangKtp, 'Belum punya / diproses'));
    stats.appendChild(statTile('Akta belum lengkap', kurangAkta, 'Belum punya / diproses'));

    var list = residents.filter(function (r) {
      if (jk && r.jk !== jk) return false;
      if (doc && r[doc] === 'Sudah punya') return false;
      if (q && (r.nama + ' ' + r.nik + ' ' + r.alamat).toLowerCase().indexOf(q) === -1) return false;
      return true;
    }).sort(function (a, b) { return a.nama.localeCompare(b.nama, 'id'); });

    var body = $('residentBody');
    body.textContent = '';
    list.forEach(function (r) {
      var tr = el('tr');
      var tdN = el('td');
      tdN.appendChild(el('span', 'name', r.nama));
      tdN.appendChild(el('span', 'sub', 'Lahir ' + fmtDate(r.lahir)));
      tr.appendChild(tdN);
      tr.appendChild(el('td', null, r.jk === 'L' ? 'L' : 'P'));
      tr.appendChild(el('td', 'nik', full ? r.nik : maskNik(r.nik)));
      tr.appendChild(el('td', null, r.alamat));
      [r.ktp, r.kk, r.akta].forEach(function (s) {
        var td = el('td'); td.appendChild(docBadge(s)); tr.appendChild(td);
      });
      var tdA = el('td', 'actions');
      tdA.appendChild(actionBtn('Ubah', '', function () { openResident(r.id); }));
      tdA.appendChild(actionBtn('Hapus', 'del', function () { deleteResident(r.id); }));
      tr.appendChild(tdA);
      body.appendChild(tr);
    });
    $('residentEmpty').hidden = list.length > 0;
  }

  ['residentSearch', 'residentJkFilter', 'residentDocFilter', 'showNik'].forEach(function (id) {
    $(id).addEventListener('input', renderResidents);
    $(id).addEventListener('change', renderResidents);
  });

  function openResident(id) {
    var r = id ? residents.filter(function (x) { return x.id === id; })[0] : null;
    $('residentDialogTitle').textContent = r ? 'Ubah data warga' : 'Tambah warga';
    $('residentId').value = r ? r.id : '';
    $('resName').value = r ? r.nama : '';
    $('resJk').value = r ? r.jk : 'L';
    $('resLahir').value = r ? r.lahir : '';
    $('resNik').value = r ? r.nik : '';
    $('resAlamat').value = r ? r.alamat : '';
    $('resKtp').value = r ? r.ktp : 'Sudah punya';
    $('resKk').value = r ? r.kk : 'Sudah punya';
    $('resAkta').value = r ? r.akta : 'Sudah punya';
    $('residentError').textContent = '';
    $('residentDialog').showModal();
  }
  $('addResidentBtn').addEventListener('click', function () { openResident(null); });

  $('residentForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var id = $('residentId').value;
    var nik = $('resNik').value.trim();
    if (!/^\d{16}$/.test(nik)) {
      $('residentError').textContent = 'NIK harus 16 digit angka.';
      return;
    }
    var dupe = residents.some(function (r) { return r.nik === nik && r.id !== id; });
    if (dupe) {
      $('residentError').textContent = 'NIK sudah terdaftar pada warga lain.';
      return;
    }
    var data = {
      nama: $('resName').value.trim(),
      jk: $('resJk').value,
      lahir: $('resLahir').value,
      nik: nik,
      alamat: $('resAlamat').value.trim(),
      ktp: $('resKtp').value,
      kk: $('resKk').value,
      akta: $('resAkta').value
    };
    if (id) {
      residents = residents.map(function (r) { return r.id === id ? Object.assign({}, r, data) : r; });
      toast('Data warga diperbarui');
    } else {
      data.id = uid();
      residents.push(data);
      toast('Warga ditambahkan');
    }
    save(KEY_RESIDENTS, residents);
    $('residentDialog').close();
    renderResidents();
  });

  function deleteResident(id) {
    var r = residents.filter(function (x) { return x.id === id; })[0];
    if (!r || !confirm('Hapus data warga ' + r.nama + '?')) return;
    residents = residents.filter(function (x) { return x.id !== id; });
    save(KEY_RESIDENTS, residents);
    renderResidents();
    toast('Data warga dihapus');
  }

  /* NIK hanya angka */
  $('resNik').addEventListener('input', function () { this.value = this.value.replace(/\D/g, '').slice(0, 16); });

  /* ---------- start ---------- */
  if (isAuthed()) showApp(); else showLogin();
})();
